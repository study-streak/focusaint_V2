// FocusShield Extension Setup Handler
document.addEventListener('DOMContentLoaded', () => {
  const grantBtn = document.getElementById('grant-btn');
  const stepPermissions = document.getElementById('step-permissions');
  const stepPermissionsBadge = document.getElementById('step-permissions-badge');
  const stepPermissionsDesc = document.getElementById('step-permissions-desc');
  const successSection = document.getElementById('success-section');
  const redirectMsg = document.getElementById('success-redirect-msg');

  // List of all domains we need permissions for
  const targetOrigins = [
    '*://*.youtube.com/*',
    '*://*.facebook.com/*',
    '*://*.twitter.com/*',
    '*://*.x.com/*',
    '*://web.whatsapp.com/*',
    '*://*.instagram.com/*',
    '*://app.slack.com/*',
    '*://*.slack.com/*',
    '*://*.reddit.com/*'
  ];

  // Check current permission status
  function checkPermission() {
    if (typeof chrome === 'undefined' || !chrome.permissions) return;

    // Check if we contain ALL target origins
    chrome.permissions.contains({
      origins: targetOrigins
    }, (result) => {
      if (result) {
        onPermissionGranted(true);
      }
    });
  }

  function onPermissionGranted(alreadyGranted) {
    // Update step UI to completed
    stepPermissions.classList.remove('active');
    stepPermissions.classList.add('completed');
    stepPermissionsBadge.textContent = '✓';
    stepPermissionsDesc.textContent = 'Social media access granted.';

    // Hide/disable the action button
    grantBtn.style.display = 'none';

    // Show the success section
    successSection.style.display = 'block';

    // Start countdown redirecting to YouTube
    let countdown = 3;
    const interval = setInterval(() => {
      countdown--;
      if (countdown <= 0) {
        clearInterval(interval);
        window.location.href = 'https://www.youtube.com/';
      } else {
        redirectMsg.textContent = `FocusShield distraction hiders are now active. Redirecting to YouTube in ${countdown}s...`;
      }
    }, 1000);
  }

  // Handle request permission click
  grantBtn.addEventListener('click', () => {
    if (typeof chrome === 'undefined' || !chrome.permissions) {
      alert('Extension environment not fully loaded.');
      return;
    }

    chrome.permissions.request({
      origins: targetOrigins
    }, (granted) => {
      if (granted) {
        onPermissionGranted(false);
      } else {
        console.warn('User declined permission.');
        alert('Permissions are required to hide recommended feeds and distraction loops on social platforms. Please click "Setup YouTube Permission" and click Allow.');
      }
    });
  });

  // Run check on page load
  checkPermission();
});
