// FocusShield Browser Extension - Popup Controller
document.addEventListener('DOMContentLoaded', () => {
  if (typeof chrome === 'undefined' || !chrome.storage) {
    console.warn('Chrome extension APIs not available.');
    return;
  }

  // --- Theme Toggle Controller ---
  const themeToggleBtn = document.getElementById('theme_toggle');
  
  // Load saved theme
  chrome.storage.local.get(['theme'], (result) => {
    if (result.theme === 'light') {
      document.body.classList.add('light-theme');
    } else {
      document.body.classList.remove('light-theme');
    }
  });

  // Toggle theme click listener
  themeToggleBtn.addEventListener('click', () => {
    const isLight = document.body.classList.toggle('light-theme');
    chrome.storage.local.set({ theme: isLight ? 'light' : 'dark' });
  });

  // --- Accordion Controller ---
  const categoryHeaders = document.querySelectorAll('.category-header');
  categoryHeaders.forEach(header => {
    header.addEventListener('click', () => {
      const category = header.parentElement;
      category.classList.toggle('expanded');
    });
  });

  // --- Platform Switcher & Context-Aware Tab Detection ---
  const tabs = document.querySelectorAll('.platform-tab');
  const sections = document.querySelectorAll('.platform-section');
  const activeTabLabel = document.getElementById('active_tab_label');

  const platformNames = {
    'youtube': 'YouTube Filter Settings',
    'twitter': 'Twitter (X) Filter Settings',
    'facebook': 'Facebook Filter Settings',
    'instagram': 'Instagram Filter Settings',
    'reddit': 'Reddit Filter Settings',
    'whatsapp-slack': 'Chat & Work Filter Settings'
  };

  function switchPlatform(platformId) {
    tabs.forEach(tab => {
      if (tab.dataset.target === platformId) {
        tab.classList.add('active');
      } else {
        tab.classList.remove('active');
      }
    });

    sections.forEach(section => {
      if (section.dataset.platform === platformId) {
        section.classList.add('active');
      } else {
        section.classList.remove('active');
      }
    });

    if (platformNames[platformId]) {
      activeTabLabel.textContent = platformNames[platformId];
    }
  }

  // Bind tab click events
  tabs.forEach(tab => {
    tab.addEventListener('click', () => {
      switchPlatform(tab.dataset.target);
    });
  });

  // Query active browser tab
  function detectActiveTabPlatform() {
    if (typeof chrome === 'undefined' || !chrome.tabs) return;

    chrome.tabs.query({ active: true, currentWindow: true }, (browserTabs) => {
      if (browserTabs && browserTabs[0] && browserTabs[0].url) {
        const urlString = browserTabs[0].url.toLowerCase();
        
        if (urlString.includes('youtube.com')) {
          switchPlatform('youtube');
        } else if (urlString.includes('twitter.com') || urlString.includes('x.com')) {
          switchPlatform('twitter');
        } else if (urlString.includes('facebook.com')) {
          switchPlatform('facebook');
        } else if (urlString.includes('instagram.com')) {
          switchPlatform('instagram');
        } else if (urlString.includes('reddit.com')) {
          switchPlatform('reddit');
        } else if (urlString.includes('whatsapp.com') || urlString.includes('slack.com')) {
          switchPlatform('whatsapp-slack');
        } else {
          // Default platform if on non-social site
          switchPlatform('youtube');
          activeTabLabel.textContent = 'FocusShield (Global Options)';
        }
      }
    });
  }

  // Detect and set active tab platform on startup
  detectActiveTabPlatform();

  // --- Host Permissions Check & Warning Banner ---
  const permissionBanner = document.getElementById('permission_banner');
  const grantPermissionBtn = document.getElementById('grant_permission_popup');
  
  const targetOrigins = [
    '*://*.youtube.com/*',
    '*://*.facebook.com/*',
    '*://*.twitter.com/*',
    '*://*.x.com/*',
    '*://web.whatsapp.com/*',
    '*://*.instagram.com/*',
    '*://app.slack.com/*',
    '*://*.slack.com/*',
    '*://*.reddit.com/*'
  ];

  function verifyAllPermissions() {
    if (!chrome.permissions) return;
    chrome.permissions.contains({
      origins: targetOrigins
    }, (hasPermission) => {
      if (hasPermission) {
        permissionBanner.style.display = 'none';
      } else {
        permissionBanner.style.display = 'flex';
      }
    });
  }

  grantPermissionBtn.addEventListener('click', () => {
    chrome.permissions.request({
      origins: targetOrigins
    }, (granted) => {
      if (granted) {
        permissionBanner.style.display = 'none';
      }
    });
  });

  // Verify permissions on popup load
  verifyAllPermissions();

  // --- Settings Checkboxes Synchronization ---
  const checkboxes = Array.from(document.querySelectorAll('input[type="checkbox"]'));
  const keys = checkboxes.map(cb => cb.id);

  // Load saved settings from local storage
  chrome.storage.local.get(keys, (storedSettings) => {
    const initialSettingsToSave = {};

    checkboxes.forEach(cb => {
      if (storedSettings[cb.id] !== undefined) {
        cb.checked = storedSettings[cb.id];
      } else {
        // If not saved before, use the default markup checked state
        initialSettingsToSave[cb.id] = cb.checked;
      }
    });

    // Write defaults to storage if they were not there
    if (Object.keys(initialSettingsToSave).length > 0) {
      chrome.storage.local.set(initialSettingsToSave);
    }
  });

  // Global change listener for dynamic settings synchronization
  document.addEventListener('change', (event) => {
    const target = event.target;
    if (target.tagName === 'INPUT' && target.type === 'checkbox') {
      const key = target.id;
      const value = target.checked;

      // Save the toggled value
      chrome.storage.local.set({ [key]: value }, () => {
        if (chrome.runtime.lastError) {
          console.error('Error saving setting:', chrome.runtime.lastError);
        }
      });

      // Special cascaded UX behavior:
      // If a parent block toggle is turned ON, expand its options tree automatically
      if (key === 'hide_sidebar' && value) {
        const sidebarTree = document.getElementById('sidebar_tree');
        if (sidebarTree && !sidebarTree.checked) {
          sidebarTree.checked = true;
          chrome.storage.local.set({ sidebar_tree: true });
        }
      }
      if (key === 'hide_comments' && value) {
        const commentTree = document.getElementById('comment_tree');
        if (commentTree && !commentTree.checked) {
          commentTree.checked = true;
          chrome.storage.local.set({ comment_tree: true });
        }
      }
      if (key === 'hide_meta' && value) {
        const metaTree = document.getElementById('meta_tree');
        if (metaTree && !metaTree.checked) {
          metaTree.checked = true;
          chrome.storage.local.set({ meta_tree: true });
        }
      }
      if (key === 'hide_header' && value) {
        const headerTree = document.getElementById('header_tree');
        if (headerTree && !headerTree.checked) {
          headerTree.checked = true;
          chrome.storage.local.set({ header_tree: true });
        }
      }
    }
  });
});
