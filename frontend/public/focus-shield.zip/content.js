// FocusShield Browser Extension - Content Filter Injection Script
(function () {
  const STYLE_ID = 'focus-shield-element-styles';

  let cachedSettings = {};

  function applyFilters() {
    const hostname = window.location.hostname.toLowerCase();

    // Tag page if on focusaint or local development
    if (hostname.includes('localhost') || hostname.includes('127.0.0.1') || hostname.includes('focusaint')) {
      document.documentElement.dataset.focusShieldInstalled = "true";
      window.dispatchEvent(new CustomEvent('FocusShieldInstalledEvent'));
    }

    // 1. Inject Stylesheets rules for element hiding
    injectStyles(hostname, cachedSettings);

    // 2. Handle redirection logic
    handleRedirection(hostname, cachedSettings);

    // 3. Handle Shadow DOM elements hiding
    applyJSFilters(hostname, cachedSettings);

    // 4. YouTube specific Autoplay control
    if (hostname.includes('youtube.com')) {
      handleAutoplay(cachedSettings);
    }
  }

  // Inject dynamic stylesheet rules (flicker-free hiding)
  function injectStyles(hostname, settings) {
    let styleEl = document.getElementById(STYLE_ID);
    if (!styleEl) {
      styleEl = document.createElement('style');
      styleEl.id = STYLE_ID;
      document.documentElement.appendChild(styleEl);
    }

    let css = '';
    const path = window.location.pathname;

    // --- YOUTUBE FILTERS ---
    if (hostname.includes('youtube.com')) {
      if (settings.hide_feed) {
        css += `
          ytd-browse[page-subtype="home"] #primary,
          ytd-browse[page-subtype="home"] ytd-rich-grid-renderer {
            display: none !important;
          }
        `;
      }

      if (settings.hide_sidebar) {
        css += `
          #secondary {
            display: none !important;
          }
        `;
      } else {
        if (settings.hide_recommended) {
          css += `
            #related,
            ytd-watch-next-service-renderer,
            #items.ytd-watch-next-service-renderer {
              display: none !important;
            }
          `;
        }
        if (settings.hide_chat) {
          css += `
            #chat,
            #show-hide-button,
            ytd-live-chat-frame {
              display: none !important;
            }
          `;
        }
        if (settings.hide_playlists) {
          css += `
            ytd-playlist-panel-renderer {
              display: none !important;
            }
          `;
        }
        if (settings.hide_donate) {
          css += `
            ytd-donation-shelf-renderer {
              display: none !important;
            }
          `;
        }
      }

      if (settings.hide_endscreen) {
        css += `
          .html5-endscreen,
          .ytp-endscreen-paginate,
          .ytp-show-share-panel {
            display: none !important;
          }
        `;
      }

      if (settings.hide_cards) {
        css += `
          .ytp-ce-element {
            display: none !important;
          }
        `;
      }

      if (settings.hide_shorts) {
        css += `
          ytd-reel-shelf-renderer,
          ytd-rich-shelf-renderer[is-shorts],
          ytd-guide-entry-renderer:has(a[href*="/shorts"]),
          ytd-mini-guide-entry-renderer:has(a[href*="/shorts"]),
          ytd-guide-entry-renderer:has(a[href="/shorts"]),
          ytd-mini-guide-entry-renderer:has(a[href="/shorts"]),
          ytd-mini-guide-entry-renderer[aria-label="Shorts"],
          ytd-guide-entry-renderer[entry-css-style="GUIDE_ENTRY_PRESENTATION_STYLE_SHORTS"],
          a[href="/shorts"],
          a[href*="/shorts"] {
            display: none !important;
          }
        `;
      }

      if (settings.hide_comments) {
        css += `
          #comments {
            display: none !important;
          }
        `;
      } else if (settings.hide_prof) {
        css += `
          #author-thumbnail,
          yt-img-shadow.ytd-comment-renderer,
          yt-img-shadow.ytd-comment-replies-renderer {
            display: none !important;
          }
        `;
      }

      if (settings.hide_mix) {
        css += `
          ytd-radio-renderer,
          ytd-compact-radio-renderer,
          a[href*="list=RD"] {
            display: none !important;
          }
        `;
      }

      if (settings.hide_merch) {
        css += `
          ytd-merch-shelf-renderer,
          ytd-ticket-shelf-renderer,
          ytd-offers-shelf-renderer {
            display: none !important;
          }
        `;
      }

      if (settings.hide_meta) {
        css += `
          #above-the-fold {
            display: none !important;
          }
        `;
      } else {
        if (settings.hide_bar) {
          css += `
            #top-row #actions,
            #actions-inner,
            #menu-container {
              display: none !important;
            }
          `;
        }
        if (settings.hide_channel) {
          css += `
            #owner,
            ytd-video-owner-renderer {
              display: none !important;
            }
          `;
        }
        if (settings.hide_desc) {
          css += `
            #description,
            ytd-expandable-video-description-body-renderer {
              display: none !important;
            }
          `;
        }
      }

      if (settings.hide_header) {
        css += `
          #masthead-container,
          ytd-masthead {
            display: none !important;
          }
          #page-manager {
            margin-top: 0 !important;
            padding-top: 0 !important;
          }
        `;
      } else if (settings.hide_notifs) {
        css += `
          ytd-notification-topbar-button-renderer {
            display: none !important;
          }
        `;
      }

      if (settings.hide_search) {
        css += `
          ytd-shelf-renderer,
          ytd-horizontal-card-list-renderer {
            display: none !important;
          }
        `;
      }

      if (settings.hide_trending) {
        css += `
          a[href="/feed/trending"],
          ytd-guide-entry-renderer:has(a[href="/feed/trending"]) {
            display: none !important;
          }
        `;
      }

      if (settings.hide_moreyt) {
        css += `
          ytd-guide-section-renderer:has(a[href^="https://www.youtube.com/premium"]),
          ytd-guide-section-renderer:has(a[href^="/gaming"]),
          ytd-guide-section-renderer:has(a[href^="/live"]) {
            display: none !important;
          }
        `;
      }

      if (settings.hide_subs) {
        css += `
          a[href="/feed/subscriptions"],
          ytd-mini-guide-entry-renderer[aria-label="Subscriptions"],
          ytd-mini-guide-entry-renderer:has(a[href*="/feed/subscriptions"]),
          ytd-guide-entry-renderer:has(a[href="/feed/subscriptions"]),
          ytd-guide-section-renderer:has(a[href="/feed/subscriptions"]),
          ytd-guide-section-renderer:has(a[href*="/feed/subscriptions"]) {
            display: none !important;
          }
        `;
      }

      if (settings.hide_annotations) {
        css += `
          .ytp-cards-button,
          .ytp-cards-teaser,
          .ytp-ce-element-show {
            display: none !important;
          }
        `;
      }
    }

    // --- TWITTER (X) FILTERS ---
    else if (hostname.includes('twitter.com') || hostname.includes('x.com')) {
      if (settings.hide_x_feed && (path === '/home' || path === '/')) {
        css += `
          [data-testid="primaryColumn"] section,
          [data-testid="primaryColumn"] div[data-testid="cellInnerDiv"] {
            display: none !important;
          }
        `;
      }
      if (settings.hide_x_trends) {
        css += `
          [data-testid="sidebarColumn"] [aria-label="Timeline: Trend"],
          [data-testid="sidebarColumn"] [data-testid="trend"],
          [aria-label="Timeline: Trends"] {
            display: none !important;
          }
        `;
      }
      if (settings.hide_x_follow) {
        css += `
          [data-testid="sidebarColumn"] [aria-label="Who to follow"] {
            display: none !important;
          }
        `;
      }
      if (settings.hide_x_explore) {
        css += `
          a[data-testid="AppTabBar_Explore_Link"] {
            display: none !important;
          }
        `;
      }
      if (settings.hide_x_notifs) {
        css += `
          a[data-testid="AppTabBar_Notifications_Link"] div[aria-label*="unread"],
          a[data-testid="AppTabBar_Notifications_Link"] div[aria-label*="Unread"],
          span[data-testid="unread-badge"] {
            display: none !important;
          }
        `;
      }
    }

    // --- FACEBOOK FILTERS ---
    else if (hostname.includes('facebook.com')) {
      if (settings.hide_fb_feed && (path === '/' || path === '/home.php')) {
        css += `
          div[role="feed"],
          [data-pagelet="FeedUnit_0"],
          [data-pagelet="FeedUnit_1"],
          [data-pagelet="FeedUnit_2"],
          #subspace-feed {
            display: none !important;
          }
        `;
      }
      if (settings.hide_fb_watch) {
        css += `
          a[aria-label="Watch"],
          a[aria-label="Reels"],
          a[href*="/watch/"],
          a[href*="/reels/"],
          div[data-pagelet="WatchTab"] {
            display: none !important;
          }
        `;
      }
      if (settings.hide_fb_stories) {
        css += `
          div[data-pagelet="StoriesContainer"],
          div[aria-label="Stories"] {
            display: none !important;
          }
        `;
      }
      if (settings.hide_fb_chat) {
        css += `
          div[data-pagelet="RightRail"],
          [aria-label="Contacts"],
          div.buddy-list {
            display: none !important;
          }
        `;
      }
    }

    // --- INSTAGRAM FILTERS ---
    else if (hostname.includes('instagram.com')) {
      if (settings.hide_ig_feed && path === '/') {
        css += `
          main[role="main"] article,
          main[role="main"] div._a9zs,
          div._a9-z,
          div._a9zs {
            display: none !important;
          }
        `;
      }
      if (settings.hide_ig_stories) {
        css += `
          div._a9z6,
          div._acaz,
          div[style*="height: 106px"],
          div._aacx {
            display: none !important;
          }
        `;
      }
      if (settings.hide_ig_explore) {
        css += `
          a[href="/explore/"],
          svg[aria-label="Explore"] {
            display: none !important;
          }
        `;
      }
      if (settings.hide_ig_reels) {
        css += `
          a[href="/reels/"],
          svg[aria-label="Reels"] {
            display: none !important;
          }
        `;
      }
    }

    // --- REDDIT FILTERS ---
    else if (hostname.includes('reddit.com')) {
      const cleanPath = path.replace(/\/$/, "");
      const isRedditFeed = cleanPath === "" || cleanPath === "/r/popular" || cleanPath === "/r/all" || cleanPath === "/hot" || cleanPath === "/new" || cleanPath === "/top" || cleanPath === "/rising";

      if (settings.hide_reddit_feed) {
        // Hide Home button in sidebar so they can't browse the feed
        css += `
          shreddit-navigation-sidebar a[href="/"],
          shreddit-navigation-sidebar a[href="/home"],
          nav a[href="/"],
          nav a[href="/home"],
          a[href="/home"] {
            display: none !important;
          }
        `;

        if (isRedditFeed) {
          css += `
            shreddit-feed,
            div[data-testid="post-container"],
            div.listings-page,
            #home-feed-list,
            shreddit-post,
            .posts-list,
            div[class*="PostList"],
            shreddit-async-input {
              display: none !important;
            }
          `;
        }
      }

      if (settings.hide_reddit_sidebar) {
        css += `
          aside[class*="sidebar"],
          #right-sidebar-container,
          div[data-reddit-sidebar],
          shreddit-sidebar {
            display: none !important;
          }
        `;
      }

      if (settings.hide_reddit_notifs) {
        css += `
          #notification-inbox-button,
          a[href="/message/inbox/"] span.badge,
          a[href="/message/inbox/"],
          #notification-inbox-button-container {
            display: none !important;
          }
        `;
      }

      if (settings.hide_reddit_explore) {
        css += `
          shreddit-navigation-sidebar a[href="/r/popular"],
          shreddit-navigation-sidebar a[href="/r/popular/"],
          shreddit-navigation-sidebar a[href$="/r/popular"],
          shreddit-navigation-sidebar a[href$="/r/popular/"],
          nav a[href="/r/popular"],
          nav a[href="/r/popular/"],
          nav a[href$="/r/popular"],
          nav a[href$="/r/popular/"],

          shreddit-navigation-sidebar a[href="/r/all"],
          shreddit-navigation-sidebar a[href="/r/all/"],
          shreddit-navigation-sidebar a[href$="/r/all"],
          shreddit-navigation-sidebar a[href$="/r/all/"],
          nav a[href="/r/all"],
          nav a[href="/r/all/"],
          nav a[href$="/r/all"],
          nav a[href$="/r/all/"],

          shreddit-navigation-sidebar a[href^="/t/"],
          shreddit-navigation-sidebar a[href*="/explore"],
          shreddit-navigation-sidebar a[href$="/explore"],
          nav a[href^="/t/"],
          nav a[href*="/explore"],
          nav a[href$="/explore"],

          faceplate-tracker[source="explore_nav"],
          faceplate-tracker[source="popular_nav"],
          faceplate-tracker[source="all_nav"],
          #popular-communities,
          faceplate-tracker[source="popular_communities"],
          [aria-label="Popular Communities"],
          div[id="popular-communities"],
          div[class*="trending-searches"],
          div:has(> h3:contains("Trending")) {
            display: none !important;
          }
        `;
      }
    }

    // --- WHATSAPP FILTERS ---
    else if (hostname.includes('whatsapp.com')) {
      if (settings.hide_wa_chat_list) {
        css += `
          #side,
          div[data-testid="side"],
          div[data-testid="chat-list-sidebar"],
          #pane-side,
          [data-testid="chat-list"] {
            display: none !important;
          }
          /* Ensure the active chat panel expands to full width when sidebar is hidden */
          div[data-testid="conversation-panel"],
          div[class*="conversation-panel"],
          ._amie,
          div.two,
          div.three {
            width: 100% !important;
            max-width: 100% !important;
            flex: 1 1 auto !important;
          }
          div[data-testid="intro-text"],
          div[class*="intro"],
          div[class*="welcome"] {
            width: 100% !important;
            max-width: 100% !important;
            flex: 1 1 auto !important;
          }
        `;
      }
      if (settings.hide_wa_status) {
        css += `
          /* Status / Stories tab button */
          div[aria-label="Status"],
          span[data-icon="status-v3"],
          span[data-icon="status-v3-unread"],
          button[aria-label="Status"],
          div[title*="Status"],
          a[href*="/status"],
          /* Channels / Updates tab button */
          div[aria-label="Updates"],
          div[aria-label="Channels"],
          span[data-icon="newsletter"],
          button[aria-label="Updates"],
          button[aria-label="Channels"],
          div[title*="Updates"],
          div[title*="Channels"],
          a[href*="/channels"],
          /* Communities tab button */
          div[aria-label="Communities"],
          span[data-icon="community"],
          span[data-icon="communities"],
          button[aria-label="Communities"],
          div[title*="Communities"] {
            display: none !important;
          }
        `;
      }
      if (settings.hide_wa_badges) {
        css += `
          span[aria-label*="unread"],
          span[aria-label*="Unread"],
          div[aria-label*="Unread"],
          span[aria-label="Unread"],
          [data-testid="unread-count"],
          [data-testid*="unread"],
          [data-testid*="badge"],
          [class*="unread-count"],
          span[class*="unread"],
          div[class*="unread"],
          span[class*="badge"],
          div[class*="badge"],
          span[class*="_unread"],
          div[class*="_unread"],
          span[class*="_badge"],
          div[class*="_badge"] {
            display: none !important;
          }
        `;
      }
    }

    // --- SLACK FILTERS ---
    else if (hostname.includes('slack.com')) {
      if (settings.hide_slack_channels) {
        css += `
          .p-channel_sidebar__list,
          .p-channel_sidebar {
            display: none !important;
          }
        `;
      }
      if (settings.hide_slack_badges) {
        css += `
          .c-mention_badge,
          .c-activity_badge {
            display: none !important;
          }
        `;
      }
    }

    styleEl.textContent = css;
  }

  // Handle Redirection logic
  function handleRedirection(hostname, settings) {
    const path = window.location.pathname;

    if (hostname.includes('youtube.com')) {
      if (settings.hide_redirect_home && (path === '/' || path === '/index.html')) {
        window.location.replace('/feed/subscriptions');
      }
    }
    else if (hostname.includes('twitter.com') || hostname.includes('x.com')) {
      if (settings.hide_x_feed && (path === '/home' || path === '/')) {
        window.location.replace('/messages');
      }
    }
    else if (hostname.includes('facebook.com')) {
      if (settings.hide_fb_feed && (path === '/' || path === '/home.php')) {
        window.location.replace('/messages/');
      }
    }
    else if (hostname.includes('instagram.com')) {
      if (settings.hide_ig_feed && path === '/') {
        window.location.replace('/direct/inbox/');
      }
    }
    else if (hostname.includes('reddit.com')) {
      const cleanPath = path.replace(/\/$/, "");
      if (settings.hide_reddit_feed && (cleanPath === "" || cleanPath === "/r/popular" || cleanPath === "/r/all")) {
        // window.location.replace('/r/getdisciplined/');
      }
    }
  }

  // Helper to query elements recursively inside Shadow DOM
  function querySelectorAllShadow(selector, root = document) {
    let matches = [];

    // Check current root
    matches = matches.concat(Array.from(root.querySelectorAll(selector)));

    // Check shadow roots recursively
    const elements = Array.from(root.querySelectorAll('*'));
    for (const el of elements) {
      if (el.shadowRoot) {
        matches = matches.concat(querySelectorAllShadow(selector, el.shadowRoot));
      }
    }

    return matches;
  }

  // Hide elements in both light DOM and Shadow DOMs
  function hideElementsJS(selector) {
    const elList = querySelectorAllShadow(selector);
    elList.forEach(el => {
      el.style.setProperty('display', 'none', 'important');
    });
  }

  // Apply JS-based filters to access Shadow DOM elements
  function applyJSFilters(hostname, settings) {
    if (hostname.includes('reddit.com')) {
      if (settings.hide_reddit_explore) {
        hideElementsJS('a[href="/r/popular"]');
        hideElementsJS('a[href="/r/popular/"]');
        hideElementsJS('a[href$="/r/popular"]');
        hideElementsJS('a[href$="/r/popular/"]');
        hideElementsJS('a[href="/r/all"]');
        hideElementsJS('a[href="/r/all/"]');
        hideElementsJS('a[href$="/r/all"]');
        hideElementsJS('a[href$="/r/all/"]');
        hideElementsJS('a[href^="/t/"]');
        hideElementsJS('a[href*="/explore"]');
        hideElementsJS('a[href$="/explore"]');
        hideElementsJS('faceplate-tracker[source="explore_nav"]');
        hideElementsJS('faceplate-tracker[source="popular_nav"]');
        hideElementsJS('faceplate-tracker[source="all_nav"]');
        hideElementsJS('#popular-communities');
        hideElementsJS('faceplate-tracker[source="popular_communities"]');
        hideElementsJS('[aria-label="Popular Communities"]');
        hideElementsJS('div[id="popular-communities"]');
      }

      if (settings.hide_reddit_feed) {
        const links = querySelectorAllShadow('a[href="/"], a[href="/home"]');
        links.forEach(link => {
          if (link.closest('shreddit-navigation-sidebar') || link.closest('nav') || link.innerText.includes('Home')) {
            link.style.setProperty('display', 'none', 'important');
          }
        });
      }

      if (settings.hide_reddit_notifs) {
        hideElementsJS('#notification-inbox-button');
        hideElementsJS('a[href="/message/inbox/"]');
        hideElementsJS('#notification-inbox-button-container');
      }
    }
  }

  // Handle YouTube Autoplay toggle logic
  function handleAutoplay(settings) {
    if (settings.hide_autoplay) {
      const checkToggleInterval = setInterval(() => {
        const toggle = document.querySelector('button.ytp-button[data-tooltip-target-id="ytp-autonav-toggle-button"]');
        if (toggle) {
          const buttonControl = toggle.querySelector('.ytp-autonav-toggle-button');
          if (buttonControl && buttonControl.getAttribute('aria-checked') === 'true') {
            toggle.click();
          }
          clearInterval(checkToggleInterval);
        }
      }, 500);

      // Stop checking after 6 seconds to save CPU cycles
      setTimeout(() => clearInterval(checkToggleInterval), 6000);
    }
  }

  // Initialize settings cache and filters on load
  if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
    chrome.storage.local.get(null, (settings) => {
      cachedSettings = settings || {};
      applyFilters();
    });

    chrome.storage.onChanged.addListener((changes) => {
      for (let [key, { newValue }] of Object.entries(changes)) {
        cachedSettings[key] = newValue;
      }
      applyFilters();
    });
  } else {
    // Fallback/direct execution
    applyFilters();
  }

  // Listen to YouTube navigation finish
  document.addEventListener('yt-navigate-finish', applyFilters);

  // Lightweight pathname polling to handle single page app transitions on all social sites
  let lastPath = window.location.pathname;
  setInterval(() => {
    if (window.location.pathname !== lastPath) {
      lastPath = window.location.pathname;
      applyFilters();
    }
  }, 500);

  // MutationObserver to watch for dynamic DOM additions and apply shadow filters reactively
  let filterTimeout = null;
  const observer = new MutationObserver(() => {
    if (filterTimeout) clearTimeout(filterTimeout);
    filterTimeout = setTimeout(() => {
      applyFilters();
    }, 200);
  });
  observer.observe(document.documentElement, {
    childList: true,
    subtree: true
  });

})();
